<?php
declare(strict_types=1);
namespace GreHack;

class Paste
{
    /**
     * @return string
     */
    public function getId(): string
    {
        return 'Flag';
    }

    /**
     * @return string
     */
    public function getContent(): string
    {
        return 'MUIEAGpmQyd3QlQRgAvAnvEfLDEb3RAVsOi7kJJE3kZNW6cOaLXgH1hpj3s807rkSAPKHCYi4O2dcyBBIEQlq_PdDG3XMvzCMjvUHoMr-7QI3QrKuMfOEOGF1_OXz8XPRMLvoQ-SsOC614NzQ-b43yLv_ygIi0CkC-Wk4SKRogGratetXKjKN49cnpq-wsAJo9wd0mUyLQ==';
    }
}
