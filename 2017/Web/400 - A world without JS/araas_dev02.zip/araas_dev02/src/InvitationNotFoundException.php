<?php
declare(strict_types=1);
namespace GreHack;

class InvitationNotFoundException extends \Exception
{
}
