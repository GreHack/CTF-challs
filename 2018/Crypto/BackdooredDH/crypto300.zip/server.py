import socket
import sys
from OpenSSL import SSL

from private.flag import FLAG

if len(sys.argv) < 2:
    print("Usage : {} <port>".format(sys.argv[0]))
    exit()

ciphersuite = "DHE-RSA-AES128-SHA256"

port = int(sys.argv[1])
host = "0.0.0.0"

ctx = SSL.Context(SSL.TLSv1_2_METHOD)

ctx.set_cipher_list(ciphersuite.encode())

ctx.use_privatekey_file("private/server_cert_private.pem", filetype=SSL.FILETYPE_PEM)
ctx.use_certificate_file("server_cert_public.pem", filetype=SSL.FILETYPE_PEM)

ctx.load_tmp_dh("server_cust0m_dhparam.pem")

server = SSL.Connection(ctx, socket.socket(socket.AF_INET, socket.SOCK_STREAM))
server.bind((host, port))
server.listen()

# async stuff is so overrated

while True:
    try:
        client, addr = server.accept()
        
        request = client.recv(1024)

        print("Got new request :\n{}".format(request.decode()))

        if b"gimme_flag_plz_am_gud_boi" in request:
            client.send("HTTP/1.0 200 OK\r\n\r\n ok grab dis : {}".format(FLAG).encode())
        else:
            client.send("HTTP/1.0 200 OK\r\n\r\n tell me u've been nice and i'll give u the flaaaag".encode())

        client.close()

    except Exception as e:
        print("Wut ??!?\n {}".format(e))

